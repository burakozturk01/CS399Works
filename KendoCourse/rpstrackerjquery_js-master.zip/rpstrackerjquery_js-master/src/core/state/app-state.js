export const INITIAL_STATE = {
  backlogItems: [],
  users: [],
  currentUser: undefined,
  currentSelectedItem: undefined,
  selectedPreset: "open",
};
