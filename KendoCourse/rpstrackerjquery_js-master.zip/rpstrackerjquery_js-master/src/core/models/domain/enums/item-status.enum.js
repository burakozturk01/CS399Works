export const StatusEnum = {
  Submitted: "Submitted",
  Open: "Open",
  Closed: "Closed",
  ReOpened: "ReOpened",
};
