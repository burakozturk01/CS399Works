export const CONFIG = {
    apiEndpoint: 'http://localhost:8080/api/',
};
