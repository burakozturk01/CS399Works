import "./index.html";
import "./styles.css";

window.location.href = "/page-dashboard/dashboard.html";
