export interface PtUserAuthInfo {
    email: string;
    password: string;
}
