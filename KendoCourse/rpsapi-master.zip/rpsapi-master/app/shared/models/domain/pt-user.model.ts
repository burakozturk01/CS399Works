import { PtObjectBase } from './';

export interface PtUser extends PtObjectBase {
    fullName: string;
    avatar: string;
}
