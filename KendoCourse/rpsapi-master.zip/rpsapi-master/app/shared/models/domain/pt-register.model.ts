export interface PtRegisterModel {
    username: string;
    password: string;
    fullName: string;
}
