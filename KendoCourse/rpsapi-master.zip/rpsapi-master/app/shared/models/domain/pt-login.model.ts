export interface PtLoginModel {
    username: string;
    password: string;
}
