export enum StatusEnum {
    Submitted = 'Submitted',
    Open = 'Open',
    Closed = 'Closed',
    ReOpened = 'ReOpened'
}
