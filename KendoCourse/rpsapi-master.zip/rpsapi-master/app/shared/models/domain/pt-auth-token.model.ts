export interface PtAuthToken {
    access_token: string;
    dateExpires: Date;
}
