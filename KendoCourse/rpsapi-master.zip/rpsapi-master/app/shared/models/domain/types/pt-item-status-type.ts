export type PtItemStatusType = 'Submitted' | 'Open' | 'Closed' | 'ReOpened';
